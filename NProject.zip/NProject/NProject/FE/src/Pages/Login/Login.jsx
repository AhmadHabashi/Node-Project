import { useState } from "react";
import classes from "./login.module.css";
import Home from "../Home/Home";

// קומפוננטת LogIn – אחראית על התחברות והרשמה של משתמש
function LogIn() {

  // ===== states של התחברות =====
  const [logEmail, setLogEmail] = useState("");        // אימייל להתחברות
  const [logPassword, setLogPassword] = useState(""); // סיסמה להתחברות
  const [logMessage, setLogMessage] = useState("");   // הודעות שגיאה / הצלחה בהתחברות

  // ===== states של הרשמה =====
  const [signUserName, setSignUseName] = useState(""); // שם משתמש להרשמה
  const [signEmail, setSignEmail] = useState("");      // אימייל להרשמה
  const [signPassword, setSignPassword] = useState(""); // סיסמה להרשמה
  const [confirmPasswod, setConfirmPasswoerd] = useState(""); // אימות סיסמה
  const [signMessage, setSignMessage] = useState("");  // הודעות שגיאה / הצלחה בהרשמה

  // state שמייצג אם המשתמש מחובר
  const [loggedIn, setLoggedIn] = useState(false);

  // ===== פונקציות עדכון שדות =====
  function handleLogEmail(e) {
    setLogEmail(e.target.value);
  }

  function handleLogPassword(e) {
    setLogPassword(e.target.value);
  }

  function handleUserName(e) {
    setSignUseName(e.target.value);
  }

  function handleSignEmail(e) {
    setSignEmail(e.target.value);
  }

  function handleSignPassword(e) {
    setSignPassword(e.target.value);
  }

  function handleConfirmPassword(e) {
    setConfirmPasswoerd(e.target.value);
  }

  // ===== פונקציית התחברות =====
  async function logIn() {
    setLogMessage("");




    // בדיקה אם השדות ריקים
    if (!logEmail || !logPassword) {
      setLogMessage("Please fill email and password");
      return;
    }

    try {
      // שליחת בקשת התחברות לשרת
      const res = await fetch("http://localhost:5000/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: logEmail,
          password: logPassword,
        }),
      });

      // קריאת התגובה מהשרת
      const data = await res.json();




      // טיפול בשגיאות מהשרת
      if (!res.ok) {
        if (data.errors) {
          setLogMessage(data.errors.join(" • "));
        } else {
          setLogMessage(data.message || "Login failed");
        }
        return;
      }

      // התחברות הצליחה
      // שמירת id של המשתמש ב-localStorage
      localStorage.setItem("id", data.user.id);


      // שליחת אירוע כדי לעדכן קומפוננטות אחרות (כמו Header)
      window.dispatchEvent(new Event("authChanged"));

      setLoggedIn(true);

      // ניקוי השדות
      setLogEmail("");
      setLogPassword("");
    } catch (err) {
      console.error(err);
      setLogMessage("Error to log in");
    }
  }

  

  // ===== פונקציית הרשמה =====
  async function signUp() {
    setSignMessage("");

    // בדיקה שכל השדות מלאים
    if (!signEmail || !signPassword || !signUserName || !confirmPasswod) {
      setSignMessage("Please fill in all the fields");
      return;
    }

    // בדיקה שהסיסמאות תואמות
    if (signPassword !== confirmPasswod) {
      setSignMessage("Passwords do not match");
      return;
    }

    try {
      // שליחת בקשת הרשמה לשרת
      const res = await fetch("http://localhost:5000/users/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: signUserName,
          email: signEmail,
          password: signPassword,
        }),
      });

      const data = await res.json();

      // טיפול בשגיאות מהשרת
      if (!res.ok) {
        if (data.errors) {
          setSignMessage(data.errors.join(" • "));
        } else {
          setSignMessage(data.message || "Signup failed");
        }
        return;
      }

      // הרשמה הצליחה
      setSignMessage(data.message || "User created!");

      // ניקוי השדות
      setSignUseName("");
      setSignEmail("");
      setSignPassword("");
      setConfirmPasswoerd("");
    } catch (err) {
      console.error(err);
      setSignMessage("Error to sign up");
    }
  }

  // אם המשתמש מחובר – מעבר אוטומטי לדף Home
  if (loggedIn) {
    return <Home />;
  }

  return (
    <div className={classes.container}>

      {/* ===== אזור התחברות ===== */}
      <div className={classes.logIn}>
        <p>Log in</p>

        <div className={classes.inputGroup}>
          <input
            type="email"
            placeholder=" "
            value={logEmail}
            onChange={handleLogEmail}
          />
          <label>Email</label>
        </div>

        <div className={classes.inputGroup}>
          <input
            type="password"
            placeholder=" "
            value={logPassword}
            onChange={handleLogPassword}
          />
          <label>Password</label>
        </div>

        <p className={classes.message}>{logMessage}</p>

        <button onClick={logIn} className={classes.shareBtn}>
          Log in
        </button>
      </div>

      {/* ===== אזור הרשמה ===== */}
      <div className={classes.signUp}>
        <p>Sign Up</p>

        <div className={classes.inputGroup}>
          <input
            type="text"
            placeholder=" "
            value={signUserName}
            onChange={handleUserName}
          />
          <label>UserName</label>
        </div>

        <div className={classes.inputGroup}>
          <input
            type="email"
            placeholder=" "
            value={signEmail}
            onChange={handleSignEmail}
          />
          <label>Email</label>
        </div>

        <div className={classes.inputGroup}>
          <input
            type="password"
            placeholder=" "
            value={signPassword}
            onChange={handleSignPassword}
          />
          <label>Password</label>
        </div>

        <div className={classes.inputGroup}>
          <input
            type="password"
            placeholder=" "
            value={confirmPasswod}
            onChange={handleConfirmPassword}
          />
          <label>Confirm Password</label>
        </div>

        <p className={classes.message}>{signMessage}</p>

        <button onClick={signUp} className={classes.shareBtn}>
          Sign Up
        </button>
      </div>
    </div>
  );
}

export default LogIn;
