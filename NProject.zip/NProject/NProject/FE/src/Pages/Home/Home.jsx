import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import classes from "./home.module.css";

// קומפוננטת Home – מציגה את רשימת המוצרים
function Home() {

  // שימוש ב־useNavigate לניווט בין עמודים (React Router)
  const navigate = useNavigate();

  // state לשמירת הטקסט של חיפוש לפי קטגוריה
  const [searchCategory, setSearchCategory] = useState("");

  // state לשמירת רשימת המוצרים מהשרת
  const [products, setProducts] = useState([]);

  // useEffect – רץ כשהקומפוננטה נטענת
  // מביא את רשימת המוצרים מהשרת
  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then((data) => setProducts(data)) // שמירת המוצרים ב-state
      .catch((err) => console.error(err));
  }, [navigate]);

  // פונקציה שמחזירה מוצרים מסוננים לפי קטגוריה
  function filteredProduct() {
    return products.filter((p) =>
      p.category.toLowerCase().includes(searchCategory.toLowerCase())
    );
  }

  // פונקציה להוספת מוצר למועדפים
  function addFavorite(productId) {

    // שליפת מזהה המשתמש מה-localStorage
    const userId = localStorage.getItem("id");

    // שליחת בקשת POST לשרת להוספה למועדפים
    fetch("http://localhost:5000/favorite/addfavorite", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId, productId }),
    })
      .then((res) => res.json())
      .catch((err) => console.error(err));
  }

  return (
    <div className={classes.container}>
      <h1 className={classes.title}>Products List</h1>


      {/* שדה חיפוש לפי קטגוריה */}
      <input
        type="text"
        placeholder="Search by Category"
        value={searchCategory}
        onChange={(e) => setSearchCategory(e.target.value)}
      />


      {/* הצגת המוצרים */}
      <div className={classes.grid}>
        {filteredProduct().map((p) => (
          <div key={p.id} className={classes.card}>
            <div className={classes.details}>
              {/* שם המוצר */}
              <h2 className={classes.name}>{p.productName}</h2>

              {/* מחיר */}
              <p className={classes.price}>{p.price}</p>

              {/* תיאור */}
              <p className={classes.description}>{p.description}</p>

              {/* כפתור הוספה למועדפים */}
              <button
                onClick={() => addFavorite(p.id)}
                className={classes.favoriteBtn}
              >
                ❤️
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;
