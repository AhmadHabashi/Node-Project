import { useState, useEffect } from "react";
import classes from "./favorites.module.css";


// קומפוננטת המועדפים שמציגה את המוצרים המועדפים של המשתמש ומאפשרת הסרה של פריטים מהמועדפים
function Favorites (){
const [favorite, setFavorite] = useState([]); ;
const userId = localStorage.getItem("id") ;

// useEffect לטעינת המוצרים המועדפים של המשתמש בעת טעינת הקומפוננטה או שינוי מזהה המשתמש  
 useEffect(() => {
   fetch(`http://localhost:5000/favorite?userId=${userId}`)
     .then((res) => res.json())
     .then((data) => setFavorite(data))
     .catch((err) => console.error(err));
 }, [userId]);


function deleteFavorite (productId){
  const userId = localStorage.getItem("id") ;

// שליחת בקשת DELETE לשרת להסרת מוצר מהמועדפים עם מזהה המוצר ומזהה המשתמש
  fetch(`http://localhost:5000/favorite/${productId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",},
      body : JSON.stringify({ userId }) ,
  })
  // טיפול בתגובה מהשרת ועדכון רשימת המוצרים המועדפים לאחר ההסרה
    .then((res) => res.json())
    .then((data) => {
      console.log(data.message); 
      setFavorite((prevFavorites) =>
        prevFavorites.filter((item) => item.id !== productId),
      );
    })
    .catch((err) => console.error(err));
}

return (
  // תצוגת המוצרים המועדפים עם אפשרות להסרה של כל מוצר מהמועדפים
  <div className= {classes.favorite}>
    <h1>My Favorites</h1>

    {favorite.length === 0 && <p className= {classes.message}>No Favorotes</p>}

    <div className= {classes.grid}>
      {favorite.map((p) => (
      <div key={p.id} className={classes.card}>
        <div className={classes.details}>
          <h2 className={classes.name}>{p.productName}</h2>
          <p className={classes.price}>{p.price}</p>
          <p className={classes.description}>{p.description}</p>
          <p onClick={() => deleteFavorite(p.id)}>❌</p>
        </div>
      </div>
    ))}
    </div>
    
  </div>
);
}
export default Favorites; 