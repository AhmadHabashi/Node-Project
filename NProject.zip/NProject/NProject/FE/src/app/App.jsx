import { useState } from "react";
import Header from "../components/header/Header";
import Footer from "../components/footer/Footer";
import Home from "../Pages/Home/Home";
import AddProduct from "../Pages/AddProduct/AddProduct";
import LogIn from "../Pages/Login/Login";
import Favorites from "../Pages/Favorites/Favorites";
import classes from "./app.module.css";

// קומפוננטת App – הקומפוננטה הראשית של האפליקציה
// אחראית על ניהול הניווט בין העמודים
export default function App() {

  // state שמחזיק איזה עמוד מוצג כרגע
  const [page, setPage] = useState("home");

  return (
    <section className={classes.app}>

      {/* Header – מקבל את setPage כדי לשנות עמודים */}
      <Header setPage={setPage} />

      {/* אזור התוכן המרכזי */}
      <main>

        {/* הצגת עמוד הבית */}
        {page === "home" && <Home />}

        {/* הצגת עמוד הוספת מוצר */}
        {page === "products" && <AddProduct />}

        {/* הצגת עמוד התחברות / הרשמה */}
        {page === "login" && <LogIn />}

        {/* הצגת עמוד מועדפים */}
        {page === "Favorite" && <Favorites />}

      </main>

      {/* Footer – מוצג בכל עמוד */}
      <Footer />
    </section>
  );
}
