import { useEffect, useState } from "react";
import classes from "./header.module.css";

// קומפוננטת כותרת עם ניווט ותצוגה מותנית של אפשרויות התחברות/התנתקות
export default function Header({ setPage }) {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem("id"));

  // useEffect להאזנה לשינויים באימות המשתמש  
  useEffect(() => {
    const check = () => setIsLoggedIn(!!localStorage.getItem("id"));
    window.addEventListener("authChanged", check);
    return () => window.removeEventListener("authChanged", check);
  }, []);


  // פונקציה לטיפול בהתנתקות המשתמש
  function handleLogOut() {
    localStorage.removeItem("id");
    window.dispatchEvent(new Event("authChanged"));
    setPage("home");
  }

  // פונקציה לטיפול בניווט לדף ההתחברות
  function handleGoLogin() {
    setPage("login");
  }

  // JSX של הכותרת עם ניווט ותצוגה מותנית של אפשרויות התחברות/התנתקות
  return (
    <header className={classes.header}>
      <h1 onClick={() => setPage("home")}>My Store</h1>

      <nav className={classes.nav}>
        <ul>
          <li onClick={() => setPage("home")} className={classes.li}>
            Home
          </li>

          <li onClick={() => setPage("products")} className={classes.li}>
            Add Product
          </li>

          <li onClick={() => setPage("Favorite")} className={classes.li}>
            Favorites
          </li>

          {!isLoggedIn ? (
            <li onClick={handleGoLogin} className={classes.li}>
              Log In
            </li>
          ) : (
            <li onClick={handleLogOut} className={classes.li}>
              Log out
            </li>
          )}
        </ul>
      </nav>
    </header>
  );
}
