//dbSingleton.js
const mysql = require("mysql2");

// משתנה לשמירת החיבור לבסיס הנתונים
let connection;

const dbSingleton = {
  getConnection: () => {
    if (!connection) {
      // יצירת חיבור לבסיס הנתונים (MySQL)
      connection = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "",
        database: "nodePro",
      });

      // התחברות לבסיס הנתונים
      connection.connect((err) => {
        if (err) {
          console.error("Error connecting to database:", err);
          throw err;
        }
        console.log("Connected to MySQL!");
      });

      
      connection.on("error", (err) => {
        console.error("Database connection error:", err);
        if (err.code === "PROTOCOL_CONNECTION_LOST") {
          connection = null; // Update the connection state
        }
      });
    }

    return connection; // Return the current connection
  },
};

module.exports = dbSingleton;
