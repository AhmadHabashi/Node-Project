const express = require("express");
const router = express.Router();
const dbSingleton = require("../db/dbSingleton");

// יצירת חיבור לבסיס הנתונים (MySQL)
const db = dbSingleton.getConnection();


//show all favorites
router.get("/", (req, res) => {
  
  const { userId } = req.query;

  const query = `SELECT p.*  FROM favorites f JOIN products p ON f.productId = p.id WHERE f.userId = ? `;

   // הרצת השאילתה עם userId
  db.query(query, [userId], (err, results) => {
    if (err)
      // שגיאת שרת
       return res.status(500).json(err);
    res.json(results);
  });
});


//add favorite   with userId and productId in the body of the request
router.post("/addfavorite", (req, res) => {
  const {userId , productId } = req.body;

  //add favorite to database with userId and productId
  const query = "INSERT INTO favorites (userId , productId ) VALUES (? ,?)";

  // הרצת השאילתה עם userId ו- productId
  db.query(query, [userId, productId], (err, results) => {
    if (err) {
      // שגיאת שרת
      res.status(500).send(err);
      return;
    }
    // החזרת תגובה עם מזהה הפריט שנוסף למועדפים
    res.json({ message: "Product added to favorites!", id: results.insertId });
  });
});




//delete favorite  
router.delete("/:productId", (req, res) => {
  // קבלת מזהה המוצר מהפרמטרים של ה-URL ומזהה המשתמש מהגוף של הבקשה
  const { productId } = req.params;
  const { userId } = req.body;

  const query = "DELETE FROM favorites WHERE userId = ? AND productId = ?";

  db.query(query, [userId, productId], (err, results) => {
    if (err) {
      // שגיאת שרת
      res.status(500).send(err);
      return;
    }
    // אם לא נמצאה רשומה למחיקה, החזרת שגיאה 404
    if (results.affectedRows === 0) {
      res.status(404).json({ message: "Favorite not found" });
    } else {
      res.json({ message: "Product removed from favorites!" });
    }
  });
});


module.exports = router;
