const path = require("path");
const userRouter = require('./Routers/user.js')
const productsRouter = require("./Routers/products.js");
const favoritesRouter = require("./Routers/favorites.js")


const express = require("express");

const app = express();
const port = 5000;

// הוספת CORS כדי לאפשר תקשורת בין השרת ל-frontend
const cors = require("cors");


app.use(
  cors({
    origin: "http://localhost:3000",
  }),
);

app.use(express.json());

app.use("/users" , userRouter) ;
app.use("/products", productsRouter);
app.use("/favorite", favoritesRouter);



app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});